import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, random, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Anton';
import narration from '../narration.json';

const {fontFamily} = loadFont();

export const FPS = 30;
// Set false untuk render tanpa VO (mis. sebelum file mp3 dibuat).
const USE_VO = true;

// ---------- Palet Candy Pastel: lilac, peach, biru langit + violet tua ----------
const THEMES = {
  lilac: {bg: '#D6C6FF', fg: '#2B1F4D', accent: '#D9381E', dim: '#5E4F8C'},
  peach: {bg: '#FFCDB0', fg: '#2B1F4D', accent: '#5B2BE0', dim: '#7A5A66'},
  sky: {bg: '#B3DCFF', fg: '#2B1F4D', accent: '#5B2BE0', dim: '#44608A'},
  night: {bg: '#2B1F4D', fg: '#F1EBFF', accent: '#FFCDB0', dim: '#B3A6D9'},
} as const;
type ThemeName = keyof typeof THEMES;

// Kata ditandai *seperti ini* untuk efek bergetar.
type Line = {t: string; size?: number; tone?: 'fg' | 'accent' | 'dim'};
type SceneDef = {sec: number; theme: ThemeName; ghost?: string; lines: Line[]};

// ---------- Naskah: total 60 detik ----------
const SCENES: SceneDef[] = [
  {sec: 5, theme: 'peach', ghost: '?', lines: [
    {t: 'Kopi itu sehat,', size: 150},
    {t: 'atau', size: 110, tone: 'dim'},
    {t: '*bahaya?*', size: 230},
  ]},
  {sec: 8, theme: 'lilac', lines: [
    {t: 'Kabar baiknya:', size: 120, tone: 'accent'},
    {t: 'risiko *diabetes tipe 2* lebih rendah', size: 118},
    {t: 'Ini hubungan, bukan sebab-akibat.', size: 72, tone: 'dim'},
  ]},
  {sec: 9, theme: 'sky', ghost: '2-3', lines: [
    {t: 'Untuk jantung?', size: 130},
    {t: '2-3 cangkir', size: 210, tone: 'accent'},
    {t: 'sehari dikaitkan dengan risiko jantung koroner lebih rendah.', size: 78, tone: 'dim'},
  ]},
  {sec: 9, theme: 'night', ghost: '400', lines: [
    {t: 'Tapi ada batasnya.', size: 120},
    {t: '400 mg', size: 270, tone: 'accent'},
    {t: 'kafein per hari. Sekitar 3-5 cangkir kopi hitam.', size: 80, tone: 'dim'},
  ]},
  {sec: 9, theme: 'peach', ghost: 'ZZZ', lines: [
    {t: 'Sisi lainnya:', size: 120, tone: 'accent'},
    {t: 'susah *tidur*', size: 170},
    {t: 'dan *cemas*', size: 170},
    {t: 'Terutama kalau kamu sensitif.', size: 76, tone: 'dim'},
  ]},
  {sec: 10, theme: 'lilac', ghost: 'GULA', lines: [
    {t: 'Bukan kopinya,', size: 140},
    {t: 'tapi *gulanya*.', size: 190, tone: 'accent'},
    {t: 'Kopi tanpa saring, seperti tubruk, bisa menaikkan kolesterol.', size: 76, tone: 'dim'},
  ]},
  {sec: 10, theme: 'sky', lines: [
    {t: 'Intinya:', size: 120, tone: 'accent'},
    {t: '*sedang-sedang* saja.', size: 170},
    {t: 'Hamil atau punya penyakit tertentu? Tanya dokter dulu.', size: 80, tone: 'dim'},
  ]},
];

export const TOTAL_FRAMES = SCENES.reduce((a, s) => a + s.sec * FPS, 0); // 1800

// ---------- Komponen ----------
const Word: React.FC<{text: string; delay: number; size: number; color: string; shake: boolean}> = ({text, delay, size, color, shake}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - delay, fps, config: {damping: 11, stiffness: 150, mass: 0.7}});

  // getar: jitter acak, diperbarui tiap 2 frame, aktif setelah kata masuk
  const f = Math.floor(frame / 2);
  const amp = shake ? Math.min(1, s) : 0;
  const jx = (random(`x-${text}-${f}`) - 0.5) * 14 * amp;
  const jy = (random(`y-${text}-${f}`) - 0.5) * 10 * amp;
  const jr = (random(`r-${text}-${f}`) - 0.5) * 5 * amp;

  return (
    <span
      style={{
        display: 'inline-block',
        fontSize: size,
        lineHeight: 1.02,
        color,
        marginRight: size * 0.22,
        opacity: Math.min(1, s * 2.5),
        transform: `translate(${jx}px, ${interpolate(s, [0, 1], [110, 0]) + jy}px) scale(${interpolate(s, [0, 1], [0.55, 1])}) rotate(${interpolate(s, [0, 1], [-4, 0]) + jr}deg)`,
      }}
    >
      {text}
    </span>
  );
};

const Scene: React.FC<{def: SceneDef}> = ({def}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const th = THEMES[def.theme];

  const fadeOut = interpolate(frame, [durationInFrames - 10, durationInFrames], [1, 0], {extrapolateLeft: 'clamp'});
  const step = Math.min(70, (durationInFrames - 70) / def.lines.length);
  const ghostScale = interpolate(frame, [0, durationInFrames], [1, 1.12]);

  return (
    <AbsoluteFill style={{background: th.bg, fontFamily, opacity: fadeOut}}>
      {def.ghost && (
        <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
          <div style={{fontSize: 760, color: th.fg, opacity: 0.07, transform: `scale(${ghostScale})`, whiteSpace: 'nowrap'}}>
            {def.ghost}
          </div>
        </AbsoluteFill>
      )}
      <AbsoluteFill style={{padding: '220px 90px 300px', justifyContent: 'center', gap: 38}}>
        {def.lines.map((line, i) => {
          const size = line.size ?? 100;
          const start = 8 + i * step;
          return (
            <div key={i} style={{display: 'flex', flexWrap: 'wrap', textTransform: 'uppercase', letterSpacing: 1}}>
              {line.t.split(' ').map((raw, j) => {
                const shake = raw.includes('*');
                const text = raw.replace(/\*/g, '');
                const color = shake ? th.accent : th[line.tone ?? 'fg'];
                return <Word key={j} text={text} delay={start + j * 3} size={size} color={color} shake={shake} />;
              })}
            </div>
          );
        })}
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

export const Video: React.FC = () => {
  const frame = useCurrentFrame();
  let from = 0;
  return (
    <AbsoluteFill style={{background: '#2B1F4D'}}>
      {SCENES.map((def, i) => {
        const dur = def.sec * FPS;
        const el = (
          <Sequence key={i} from={from} durationInFrames={dur}>
            <Scene def={def} />
            {USE_VO && narration[i] && (
              <Sequence from={9}>
                <Audio src={staticFile(`vo/scene-${i + 1}.mp3`)} />
              </Sequence>
            )}
          </Sequence>
        );
        from += dur;
        return el;
      })}
      {/* bar progres */}
      <div style={{position: 'absolute', left: 0, bottom: 0, width: '100%', height: 18, background: 'rgba(43,31,77,0.15)'}}>
        <div style={{height: '100%', width: `${(frame / TOTAL_FRAMES) * 100}%`, background: '#8B5CF6'}} />
      </div>
    </AbsoluteFill>
  );
};
