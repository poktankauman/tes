import React from 'react';
import {Composition} from 'remotion';
import {Video, TOTAL_FRAMES, FPS} from './Video';

export const Root: React.FC = () => (
  <Composition
    id="SeninUpacara"
    component={Video}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={1080}
    height={1920}
  />
);
