import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import narration from '../narration.json';
import {loadFont} from '@remotion/google-fonts/Anton';

const {fontFamily} = loadFont();

export const FPS = 30;
// Set false untuk render tanpa VO (mis. sebelum file mp3 dibuat).
const USE_VO = true;

// ---------- Palet: merah-putih bendera + tinta gelap ----------
const THEMES = {
  ink: {bg: '#16161D', fg: '#FFFFFF', accent: '#FF3B3F', dim: '#9A9AA8'},
  red: {bg: '#D7141A', fg: '#FFFFFF', accent: '#16161D', dim: '#FFC9CB'},
  white: {bg: '#FFFFFF', fg: '#16161D', accent: '#D7141A', dim: '#7A7A86'},
} as const;
type ThemeName = keyof typeof THEMES;

type Line = {t: string; size?: number; tone?: 'fg' | 'accent' | 'dim'};
type SceneDef = {sec: number; theme: ThemeName; ghost?: string; lines: Line[]};

// ---------- Naskah: total 100 detik ----------
const SCENES: SceneDef[] = [
  {sec: 8, theme: 'ink', lines: [
    {t: 'Setiap Senin.', size: 150},
    {t: 'Kita berdiri.', size: 150},
    {t: 'Di lapangan.', size: 150},
    {t: 'Kenapa?', size: 210, tone: 'accent'},
  ]},
  {sec: 10, theme: 'white', ghost: '?', lines: [
    {t: 'Bukan sekadar rutinitas.', size: 120},
    {t: 'Bukan cuma soal topi dan dasi.', size: 84, tone: 'dim'},
    {t: 'Ada ceritanya.', size: 150, tone: 'accent'},
  ]},
  {sec: 16, theme: 'ink', ghost: '1942', lines: [
    {t: '1942', size: 260, tone: 'accent'},
    {t: 'Jepang menduduki Indonesia.', size: 100},
    {t: 'Sekolah dan kantor wajib berkumpul tiap pagi.', size: 80, tone: 'dim'},
    {t: 'Kebiasaan baris dan hormat bersama mulai mengakar.', size: 80, tone: 'dim'},
  ]},
  {sec: 16, theme: 'red', ghost: '1945', lines: [
    {t: '17 Agustus 1945', size: 140},
    {t: 'Merah Putih dikibarkan sebagai bendera negara merdeka.', size: 88},
    {t: 'Sejak itu, menghormati bendera berarti menghormati perjuangan.', size: 80, tone: 'accent'},
  ]},
  {sec: 18, theme: 'white', ghost: 'SENIN', lines: [
    {t: 'Lalu, kenapa Senin?', size: 130, tone: 'accent'},
    {t: 'Awal pekan.', size: 160},
    {t: 'Semua murid hadir. Semua siap mulai.', size: 88},
    {t: 'Pilihan hari ini lebih ke tradisi, bukan mitos.', size: 76, tone: 'dim'},
  ]},
  {sec: 12, theme: 'ink', ghost: '2018', lines: [
    {t: 'Sekarang ada aturannya.', size: 110},
    {t: 'Permendikbud No. 22 Tahun 2018', size: 96, tone: 'accent'},
    {t: 'Pedoman upacara bendera di sekolah.', size: 80, tone: 'dim'},
  ]},
  {sec: 12, theme: 'red', lines: [
    {t: 'Disiplin.', size: 190},
    {t: 'Kebersamaan.', size: 160},
    {t: 'Cinta tanah air.', size: 130, tone: 'accent'},
  ]},
  {sec: 8, theme: 'white', lines: [
    {t: 'Lain kali berdiri di lapangan,', size: 84, tone: 'dim'},
    {t: 'ingat: kamu sedang meneruskan cerita.', size: 96},
    {t: 'Merdeka!', size: 220, tone: 'accent'},
  ]},
];

export const TOTAL_FRAMES = SCENES.reduce((a, s) => a + s.sec * FPS, 0); // 3000

// ---------- Komponen ----------
const Word: React.FC<{text: string; delay: number; size: number; color: string}> = ({text, delay, size, color}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - delay, fps, config: {damping: 11, stiffness: 150, mass: 0.7}});
  return (
    <span
      style={{
        display: 'inline-block',
        fontSize: size,
        lineHeight: 1.02,
        color,
        marginRight: size * 0.22,
        opacity: Math.min(1, s * 2.5),
        transform: `translateY(${interpolate(s, [0, 1], [110, 0])}px) scale(${interpolate(s, [0, 1], [0.55, 1])}) rotate(${interpolate(s, [0, 1], [-4, 0])}deg)`,
      }}
    >
      {text}
    </span>
  );
};

const Scene: React.FC<{def: SceneDef}> = ({def}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const th = THEMES[def.theme];

  const fadeOut = interpolate(frame, [durationInFrames - 10, durationInFrames], [1, 0], {
    extrapolateLeft: 'clamp',
  });
  const step = Math.min(70, (durationInFrames - 70) / def.lines.length);
  const ghostScale = interpolate(frame, [0, durationInFrames], [1, 1.12]);

  return (
    <AbsoluteFill style={{background: th.bg, fontFamily, opacity: fadeOut}}>
      {def.ghost && (
        <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
          <div style={{fontSize: 760, color: th.fg, opacity: 0.07, transform: `scale(${ghostScale})`, whiteSpace: 'nowrap'}}>
            {def.ghost}
          </div>
        </AbsoluteFill>
      )}
      <AbsoluteFill style={{padding: '220px 90px 300px', justifyContent: 'center', gap: 38}}>
        {def.lines.map((line, i) => {
          const color = th[line.tone ?? 'fg'];
          const size = line.size ?? 100;
          const start = 8 + i * step;
          return (
            <div key={i} style={{display: 'flex', flexWrap: 'wrap', textTransform: 'uppercase', letterSpacing: 1}}>
              {line.t.split(' ').map((w, j) => (
                <Word key={j} text={w} delay={start + j * 3} size={size} color={color} />
              ))}
            </div>
          );
        })}
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

export const Video: React.FC = () => {
  const frame = useCurrentFrame();
  let from = 0;
  return (
    <AbsoluteFill style={{background: '#16161D'}}>
      {SCENES.map((def, i) => {
        const dur = def.sec * FPS;
        const el = (
          <Sequence key={i} from={from} durationInFrames={dur}>
            <Scene def={def} />
            {USE_VO && narration[i] && (
              <Sequence from={9}>
                <Audio src={staticFile(`vo/scene-${i + 1}.mp3`)} />
              </Sequence>
            )}
          </Sequence>
        );
        from += dur;
        return el;
      })}
      {/* bar progres: merah di atas putih, seperti bendera */}
      <div style={{position: 'absolute', left: 0, bottom: 0, width: '100%', height: 18, background: '#FFFFFF'}}>
        <div style={{height: '100%', width: `${(frame / TOTAL_FRAMES) * 100}%`, background: '#D7141A'}} />
      </div>
    </AbsoluteFill>
  );
};
