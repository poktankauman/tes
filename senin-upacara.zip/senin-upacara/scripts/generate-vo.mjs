// Membuat public/vo/scene-N.mp3 dari narration.json memakai edge-tts (gratis).
// Prasyarat: pip install edge-tts
import {readFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';

const VOICE = process.env.VOICE || 'id-ID-ArdiNeural'; // atau id-ID-GadisNeural
const RATE = process.env.RATE || '+0%';
const scenes = JSON.parse(readFileSync('narration.json', 'utf8'));

scenes.forEach((s, i) => {
  const out = `public/vo/scene-${i + 1}.mp3`;
  execFileSync('edge-tts', ['--voice', VOICE, `--rate=${RATE}`, '--text', s.text, '--write-media', out], {stdio: 'inherit'});
  try {
    const d = parseFloat(
      execFileSync('npx', ['remotion', 'ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', out]).toString()
    );
    const limit = s.sec - 0.8;
    console.log(`scene-${i + 1}: ${d.toFixed(1)}s / batas ${limit.toFixed(1)}s ${d > limit ? '⚠ TERLALU PANJANG (naikkan RATE, mis. RATE=+10%)' : 'OK'}`);
  } catch {
    console.log(`scene-${i + 1}: dibuat (cek durasi manual)`);
  }
});
